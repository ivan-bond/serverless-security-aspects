
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'presentolo',
  applicationName: 'serverless-aws-security',
  appUid: 'p1qwhQJVLGHVyrHbDz',
  orgUid: 'c0276d8a-f6ec-4494-9aed-aad7e8d117f4',
  deploymentUid: '73010aa7-54af-4b7e-94fc-5757518fce9b',
  serviceName: 'aws-node-http-api-project',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'aws-node-http-api-project-dev-dethrottlingFunction', timeout: 6 };

try {
  const userHandler = require('./src/handler/dethrottling.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}