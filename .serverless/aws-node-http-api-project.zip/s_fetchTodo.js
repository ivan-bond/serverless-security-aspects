
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'presentolo',
  applicationName: 'serverless-aws-security',
  appUid: 'p1qwhQJVLGHVyrHbDz',
  orgUid: 'c0276d8a-f6ec-4494-9aed-aad7e8d117f4',
  deploymentUid: '63cf0f76-1a09-4a2b-90bd-107bf07c7af9',
  serviceName: 'aws-node-http-api-project',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'aws-node-http-api-project-dev-fetchTodo', timeout: 6 };

try {
  const userHandler = require('./src/handler/fetchTodo.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}